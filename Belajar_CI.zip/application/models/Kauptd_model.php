<?php 


if ( ! defined('BASEPATH')) exit('No direct script access allowed');


    class Kauptd_model extends CI_Model {


        public function tambahDataKaryawan(){
             $data = [
                    "username" => $this->input->post('txt_username', true),
                    "password" => $this->input->post('txt_password', true),
                    "nama" => $this->input->post('txt_nama', true),
                    "level" => $this->input->post('txt_level', true),
                    "nip" => $this->input->post('txt_nip', true),
                    "gender" => $this->input->post('txt_gender', true),
                    "no_hp" => $this->input->post('txt_nohp', true),
                    "ttl" => $this->input->post('txt_tanggal', true)
                ];

                $this->db->insert('login', $data);
         }

        public function getAlldataKaryawan(){


      
        $query = $this->db->query('SELECT * FROM login WHERE level !=4');

        return $query->result_array();

        }

        public function HapusDataKaryawan($id)
        {       
                $this->db->where('username', $id);
                $this->db->delete('login');
        }

         public function getKaryawanbyUsername($id)
        {

           return $this->db->get_where('login', ['username' =>$id])->row_array();
        }



            public function UbahDataKaryawan(){

            $data = [
                     "username" => $this->input->post('txt_username', true),
                    "password" => $this->input->post('txt_password', true),
                    "nama" => $this->input->post('txt_nama', true),
                    "level" => $this->input->post('txt_level', true),
                    "nip" => $this->input->post('txt_nip', true),
                    "gender" => $this->input->post('txt_gender', true),
                    "no_hp" => $this->input->post('txt_nohp', true),
                    "ttl" => $this->input->post('txt_tanggal', true)
                ];

                $this->db->where('id', $this->input->post('txt_id'));
                $this->db->update('login', $data);
            
         }

         public function Getdatakauptd(){
             $data = [
                    "password" => $this->input->post('txt_password', true),
                    "nama" => $this->input->post('txt_nama', true),
                    "level" => $this->input->post('txt_level', true),
                    "nip" => $this->input->post('txt_nip', true),
                    "gender" => $this->input->post('txt_gender', true),
                    "no_hp" => $this->input->post('txt_nohp', true),
                    "ttl" => $this->input->post('txt_tanggal', true)
                ];

                $this->db->where('id', $this->input->post('txt_id'));
                $this->db->update('login', $data);

            
         }



         public function tambahDataPemohon(){
             $data = [
                    "username" => $this->input->post('txt_username', true),
                    "password" => $this->input->post('txt_password', true),
                    "nama" => $this->input->post('txt_nama', true),
                    "level" => $this->input->post('txt_level', true),
                    "nip" => $this->input->post('txt_nip', true),
                    "gender" => $this->input->post('txt_gender', true),
                    "no_hp" => $this->input->post('txt_nohp', true),
                    "ttl" => $this->input->post('txt_tanggal', true)
                ];

                $this->db->insert('login', $data);
         }
    
       
       public function getAlldataPemohon(){
          

        $level = '4';
        $lvl = $this->db->where('level', $level);
        $query = $this->db->get('login');

        return $query->result_array();

        }

        public function getAlldataPengajuan(){

            $query = $this->db->get('pengajuan');
            return $query->result_array();
        }


        public function getPengajuanbyID($id){
             return $this->db->get_where('pengajuan', ['id_pengajuan' =>$id])->row_array();
            
        }

        public function prosesterima($id)
        {

            $data = '2';
            $this->db->set('status', $data);
            $this->db->where('id_pengajuan', $id);
            $this->db->update('pengajuan');
            
        }

        public function prosestolak($id)
        {

            $data = '0';
            $this->db->set('status', $data);
            $this->db->where('id_pengajuan', $id);
            $this->db->update('pengajuan');
            
        }

       

            
        }

?>