<!DOCTYPE html>
<html><head>
    <title>Laporan Data Sapi</title>

    <h1><center><font size="5" face="arial">DINAS PERTANIAN DAN KETAHAN PANGAN</font></center></h1>
	<center><b><font size="4" face="Courier New">KOTA PALEMBANG</font></b></center><br>
	<center><b> Jalan TP. H, Jl. Sofian Kenawas, Gandus, Kota Palembang -30149<b></center><br>
    <hr><width="100" height="75"></hr>
</head><body>
	

<h3><center>Laporan Data Sapi RPH Gandus</center></h3>
<table style="border-collapse: collapse; width:100%; margin-top: 5px;">
  <tr>
    <th style="border:1px solid">Nomor Telinga</th>
    <th style="border:1px solid">Ras</th>
    <th style="border:1px solid">Berat</th>
    <th style="border:1px solid">Gender</th>
    <th style="border:1px solid">Atas Nama</th>
    <th style="border:1px solid">Tanggal masuk</th>
  </tr>
  <?php foreach($sapi as $sapi_data) :?>
  <tr>
    <th style="border:1px solid"><?= $sapi_data['no_telinga'];?></th>
    <th style="border:1px solid"><?= $sapi_data['ras'];?></th>
    <th style="border:1px solid"><?= $sapi_data['berat'];?></th>
    <th style="border:1px solid"><?= $sapi_data['gender'];?></th>
    <th style="border:1px solid"><?= $sapi_data['username'];?></th>
    <th style="border:1px solid"><?= $sapi_data['tanggal_masuk'];?></th>
   
  </tr>
<?php endforeach; ?>
</table>
</body></html>