<?php

class Dashboard_Pemohon extends CI_Controller {

	 public function index() {


	 		echo "string";
	 }






    }

?>